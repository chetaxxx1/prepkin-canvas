# SAT lesson system — archived 2026-09-08

Prepkin stopped being an SAT app on 2026-09-08 (design/SOCIAL-PLAN.md §0). It aims at
college undergraduates now, and undergraduates do not take the SAT. Everything the app
had for teaching the test is in this zip and nowhere else in the repo.

## What is here

- `Content/lessons.json` — 57 micro-lessons across three tracks, with cards, figures,
  blurbs and takeaways. The largest single piece of content this project ever made.
- `Sources/LessonDeckView.swift` (995 lines) — the reader: cards, build steps, progress.
- `Sources/LessonFigures.swift` (3,537 lines) — every hand-drawn SwiftUI figure.
- `Sources/LessonCover.swift`, `LessonPreviewSheet.swift`, `TrackMapView.swift`,
  `SavedCardsView.swift`, `LearnIcons.swift` — covers, preview, the track map, saved
  cards, the track icons.
- `Sources/LearnView.swift`, `AppState.swift`, `Content.swift`, `GameState.swift` and
  the three test files — **whole copies as they stood before the rip**, because the
  lesson code in these was cut out of them rather than deleted with them. If any of this
  ever comes back, diff against these rather than trying to remember.

## What was cut from the files that stayed

- `Lesson`, `LessonCard`, `Track`, `SavedCard` and every `Catalog` accessor for them.
- `GameState.completedLessons`, `deckProgress`, `savedCards`, `cardReports`.
- `CoinReason.lesson`, and the lesson half of the daily coin pool.
- The Learn tab's Continue card, daily picks, track shelf and saved row. What is left of
  that screen is the Play rail, which is why the tab is now called Play.

## The related work that was NOT deleted

The generators and skills that made this content still exist and are not in this zip:
`design/figure-art`, `charts.py`, `chartkit`, the Recraft and Gemini figure pipelines,
and the `sat-*` skills. They are tools, and tools keep.

Restoring: unzip over the repo, then `xcodegen generate`. It will not compile as-is —
the app moved on — but every line is here.
